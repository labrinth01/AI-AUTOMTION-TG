from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    BOT_TOKEN: str
    OPENROUTER_API_KEY: str
    DATABASE_URL: str = "sqlite+aiosqlite:///./data/bot.db"

    model_config = {"env_file": ".env"}


settings = Settings()
