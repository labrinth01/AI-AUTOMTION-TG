from aiogram.fsm.state import State, StatesGroup


class PromptForm(StatesGroup):
    waiting_for_prompt = State()
