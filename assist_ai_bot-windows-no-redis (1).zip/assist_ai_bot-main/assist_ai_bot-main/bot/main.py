import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties

from bot.handlers import business, prompt, start
from bot.middleware import DatabaseMiddleware
from config import settings
from db.database import init_db

ALLOWED_UPDATES = [
    "message",
    "callback_query",
    "business_connection",
    "business_message",
]


async def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    await init_db()

    bot = Bot(
        token=settings.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode="HTML"),
    )
    dp = Dispatcher()

    dp.update.middleware(DatabaseMiddleware())

    dp.include_router(start.router)
    dp.include_router(prompt.router)
    dp.include_router(business.router)

    await dp.start_polling(bot, allowed_updates=ALLOWED_UPDATES)


if __name__ == "__main__":
    asyncio.run(main())
