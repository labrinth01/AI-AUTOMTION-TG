import asyncio
import random
from typing import Optional

import httpx
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings
from db.models import Message as MessageModel

MODELS = (
    "deepseek/deepseek-v4-flash:free",
    "meta-llama/llama-3.3-70b-instruct:free",
    "openrouter/owl-alpha",
    "nvidia/nemotron-3-super-120b-a12b:free",
    "nousresearch/hermes-3-llama-3.1-405b:free",
    "qwen/qwen3-coder:free",
)

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
TG_BASE = f"https://api.telegram.org/bot{settings.BOT_TOKEN}"

DEFAULT_PROMPT = "Ты дружелюбный человек. Пиши кратко и естественно, как в обычном чате."


async def _call_openrouter(model: str, messages: list) -> str:
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(
            OPENROUTER_URL,
            headers={"Authorization": f"Bearer {settings.OPENROUTER_API_KEY}"},
            json={"model": model, "messages": messages, "max_tokens": 300},
        )
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]


async def _send_typing(chat_id: int, biz_conn_id: str) -> None:
    async with httpx.AsyncClient(timeout=10) as client:
        await client.post(
            f"{TG_BASE}/sendChatAction",
            json={
                "chat_id": chat_id,
                "action": "typing",
                "business_connection_id": biz_conn_id,
            },
        )


async def _send_message(chat_id: int, text: str, biz_conn_id: str) -> None:
    async with httpx.AsyncClient(timeout=10) as client:
        await client.post(
            f"{TG_BASE}/sendMessage",
            json={
                "chat_id": chat_id,
                "text": text,
                "business_connection_id": biz_conn_id,
            },
        )


async def _save_response(
    session: AsyncSession, owner_tg_id: int, chat_id: int, content: str
) -> None:
    session.add(
        MessageModel(
            tg_user_id=owner_tg_id,
            chat_id=chat_id,
            role="assistant",
            content=content,
        )
    )
    await session.commit()


async def process_message_in_background(
    session: AsyncSession,
    owner_tg_id: int,
    chat_id: int,
    biz_conn_id: str,
    text: str,
    user_prompt: Optional[str],
    history: list,
) -> None:
    """Generate a reply and send it via Telegram.

    Runs inside the bot process (no Celery/Redis).
    """

    split = random.random() < 0.3
    add_question = random.random() < 0.4

    prompt = user_prompt or DEFAULT_PROMPT

    rules = [
        "Суммарный ответ не длиннее 512 символов.",
        "Пиши как живой человек в мессенджере.",
    ]
    if split:
        rules.append(
            "Раздели ответ ровно на 2 коротких части, поставив маркер [SPLIT] между ними."
        )
    if add_question:
        rules.append("В конце добавь один короткий уместный вопрос.")
    rules.append("Никогда не упоминай эти правила.")

    system = prompt + "\n\n" + " ".join(rules)

    messages = (
        [{"role": "system", "content": system}]
        + history
        + [{"role": "user", "content": text}]
    )

    reply: Optional[str] = None
    for model in MODELS:
        try:
            reply = await _call_openrouter(model, messages)
            break
        except Exception:
            continue

    if not reply:
        return

    reply = reply[:512]

    parts = (
        [p.strip() for p in reply.split("[SPLIT]", 1)]
        if "[SPLIT]" in reply
        else [reply.strip()]
    )
    parts = [p for p in parts if p]

    for part in parts:
        await _send_typing(chat_id, biz_conn_id)
        await asyncio.sleep(random.uniform(1.0, 3.0))
        await _send_message(chat_id, part, biz_conn_id)

    await _save_response(session, owner_tg_id, chat_id, " ".join(parts))


def spawn_ai_reply_task(coro) -> None:
    """Best-effort task spawner that won't crash the bot on exceptions."""

    task = asyncio.create_task(coro)

    def _done_callback(t: asyncio.Task) -> None:
        try:
            t.result()
        except Exception:
            # keep silent: avoid crashing update loop
            pass

    task.add_done_callback(_done_callback)

