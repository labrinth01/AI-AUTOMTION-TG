from aiogram import Router
from aiogram.types import BusinessConnection, Message
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from db.models import BusinessConnection as BCModel
from db.models import Message as MessageModel
from db.models import User
from bot.ai import process_message_in_background, spawn_ai_reply_task

router = Router()


@router.business_connection()
async def on_business_connection(event: BusinessConnection, session: AsyncSession) -> None:
    existing = await session.get(BCModel, event.id)
    if existing:
        existing.is_enabled = event.is_enabled
        existing.can_reply = event.can_reply
        existing.tg_user_id = event.user.id
    else:
        session.add(
            BCModel(
                id=event.id,
                tg_user_id=event.user.id,
                is_enabled=event.is_enabled,
                can_reply=event.can_reply,
            )
        )
    await session.commit()


@router.business_message()
async def handle_business_message(message: Message, session: AsyncSession) -> None:
    if not message.business_connection_id or not message.text:
        return

    bc = await session.get(BCModel, message.business_connection_id)
    if not bc or not bc.is_enabled or not bc.can_reply:
        return

    owner_id = bc.tg_user_id

    # Не отвечаем на сообщения самого владельца
    if message.from_user and message.from_user.id == owner_id:
        return

    # Промпт владельца
    user = await session.scalar(select(User).where(User.tg_id == owner_id))
    user_prompt = user.prompt if user and user.prompt else None

    # Последние 10 сообщений для контекста (до текущего)
    rows = await session.execute(
        select(MessageModel)
        .where(
            MessageModel.tg_user_id == owner_id,
            MessageModel.chat_id == message.chat.id,
        )
        .order_by(MessageModel.created_at.desc())
        .limit(10)
    )
    history = [
        {"role": m.role, "content": m.content}
        for m in reversed(rows.scalars().all())
    ]

    # Сохраняем входящее сообщение
    session.add(
        MessageModel(
            tg_user_id=owner_id,
            chat_id=message.chat.id,
            role="user",
            content=message.text,
        )
    )
    await session.commit()

    # Генерация ответа в фоне (без Celery/Redis)
    spawn_ai_reply_task(
        process_message_in_background(
            session,
            owner_id,
            message.chat.id,
            message.business_connection_id,
            message.text,
            user_prompt,
            history,
        )
    )
