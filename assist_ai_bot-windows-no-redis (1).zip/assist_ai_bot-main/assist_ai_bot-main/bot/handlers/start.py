from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from bot.keyboards import main_menu
from db.models import User

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    await message.answer(
        "👋 Привет!\n\n"
        "Я помогу тебе автоматически отвечать в Telegram Business чатах.\n\n"
        "<b>Как настроить:</b>\n"
        "1. Открой <b>Настройки → Telegram Business → Чат-боты</b>\n"
        "2. Добавь меня как бота-помощника и выбери чаты\n"
        "3. Задай промпт ниже — опиши свой стиль общения\n\n"
        "Я буду отвечать вместо тебя именно в том стиле, который ты опишешь.",
        reply_markup=main_menu(),
    )


@router.callback_query(F.data == "view_prompt")
async def view_prompt(callback: CallbackQuery, session: AsyncSession) -> None:
    user = await session.scalar(select(User).where(User.tg_id == callback.from_user.id))
    if user and user.prompt:
        await callback.message.answer(f"📋 <b>Твой промпт:</b>\n\n{user.prompt}")
    else:
        await callback.message.answer(
            "У тебя пока нет промпта. Нажми «Задать промпт» чтобы добавить."
        )
    await callback.answer()
