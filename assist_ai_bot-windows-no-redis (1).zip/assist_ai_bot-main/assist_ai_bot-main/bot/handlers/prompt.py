from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.dialects.sqlite import insert
from sqlalchemy.ext.asyncio import AsyncSession

from bot.keyboards import cancel_keyboard, main_menu
from bot.states import PromptForm
from db.models import User

router = Router()


@router.callback_query(F.data == "set_prompt")
async def ask_prompt(callback: CallbackQuery, state: FSMContext) -> None:
    await callback.message.answer(
        "✍️ <b>Напиши свой промпт</b>\n\n"
        "Опиши как ты общаешься: стиль, манеру речи, интересы, как обычно отвечаешь.\n\n"
        "<i>Пример: «Я общаюсь неформально, без смайликов, кратко. "
        "По работе я разработчик, поэтому в технических темах отвечаю подробнее. "
        "Люблю пошутить, но без перегибов»</i>",
        reply_markup=cancel_keyboard(),
    )
    await state.set_state(PromptForm.waiting_for_prompt)
    await callback.answer()


@router.callback_query(F.data == "cancel")
async def cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.answer("Отменено.", reply_markup=main_menu())
    await callback.answer()


@router.message(PromptForm.waiting_for_prompt)
async def save_prompt(message: Message, state: FSMContext, session: AsyncSession) -> None:
    if not message.text:
        await message.answer("Пожалуйста, отправь текст.")
        return

    prompt_text = message.text.strip()
    if len(prompt_text) < 10:
        await message.answer("Промпт слишком короткий. Напиши хотя бы 10 символов.")
        return

    stmt = insert(User).values(tg_id=message.from_user.id, prompt=prompt_text)
    stmt = stmt.on_conflict_do_update(
        index_elements=["tg_id"], set_={"prompt": prompt_text}
    )
    await session.execute(stmt)
    await session.commit()

    await state.clear()
    await message.answer(
        "✅ <b>Промпт сохранён!</b>\n\n"
        "Теперь бот будет отвечать в твоём стиле во всех подключённых чатах.",
        reply_markup=main_menu(),
    )
