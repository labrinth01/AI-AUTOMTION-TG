# Deploy на хостинг (без Docker)

Ниже — минимальный вариант деплоя на VPS (Ubuntu/Debian). Подходит для обычного хостинга с SSH.

## 0) Что нужно на сервере
- Python 3.10+
- Redis
- Git

## 1) Установка пакетов (Ubuntu)
```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip redis-server git
sudo systemctl enable --now redis-server
```

## 2) Заливка проекта
```bash
cd /opt
sudo git clone <YOUR_REPO_URL> assist_ai_bot
sudo chown -R $USER:$USER /opt/assist_ai_bot
cd /opt/assist_ai_bot
```

## 3) Env
```bash
cp .env.example .env
nano .env
```
Проверь:
- `BOT_TOKEN=...`
- `OPENROUTER_API_KEY=...`
- `REDIS_URL=redis://localhost:6379/0`

## 4) Виртуальное окружение
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -r requirements.txt
```

## 5) systemd (2 сервиса)
Скопируй юниты из папки `deploy/systemd/`:

```bash
sudo cp deploy/systemd/assist-bot.service /etc/systemd/system/assist-bot.service
sudo cp deploy/systemd/assist-worker.service /etc/systemd/system/assist-worker.service
sudo systemctl daemon-reload
sudo systemctl enable --now assist-worker.service
sudo systemctl enable --now assist-bot.service
```

Проверка логов:
```bash
sudo journalctl -u assist-worker -f
sudo journalctl -u assist-bot -f
```

## Обновление
```bash
cd /opt/assist_ai_bot
git pull
source .venv/bin/activate
pip install -r requirements.txt
sudo systemctl restart assist-worker assist-bot
```
