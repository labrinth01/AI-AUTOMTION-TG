# 🤖 Telegram Business AutoReply Bot

Бот-автоответчик для **Telegram Business** — отвечает в твоих личных чатах вместо тебя, используя AI. Каждый пользователь задаёт свой промпт, и бот общается именно в его стиле.

---

## Что это такое

В Telegram появилась функция **Chat Automation** (Telegram Business). Она позволяет подключить бота к своему аккаунту, выбрать нужные чаты — и бот будет автоматически отвечать на сообщения от твоего имени.

Этот проект реализует такого бота: он принимает сообщения, отправляет их в AI (OpenRouter), и возвращает ответ в стиле, который ты сам описал в промпте.

---

## Use-cases

- 📵 **Ты недоступен** — бот отвечает коллегам, клиентам или друзьям пока ты занят
- 💼 **Бизнес-чаты** — автоматические вежливые ответы на типовые вопросы
- ✈️ **Отпуск / оффлайн** — никто не ждёт ответа часами
- 🧪 **Эксперимент** — посмотреть, заметят ли друзья что с ними говорит AI

---

## Стек

| Технология | Роль |
|---|---|
| [aiogram 3](https://docs.aiogram.dev/) | Telegram Bot framework |
| [SQLAlchemy](https://sqlalchemy.org/) + aiosqlite | Async ORM + SQLite |
| [Celery](https://docs.celeryq.dev/) + Redis | Очередь задач для AI запросов |
| [httpx](https://www.python-httpx.org/) | HTTP клиент |
| [OpenRouter](https://openrouter.ai/) | AI Gateway (бесплатные модели) |

**AI модели (fallback цепочка):**
1. `deepseek/deepseek-v4-flash:free`
2. `meta-llama/llama-3.3-70b-instruct:free`
3. `openrouter/owl-alpha`
4. `nvidia/nemotron-3-super-120b-a12b:free`
5. `nousresearch/hermes-3-llama-3.1-405b:free`
6. `qwen/qwen3-coder:free`

Если одна модель вернула 429 — автоматически пробует следующую.

---

## Архитектура

```
Входящее сообщение (Telegram Business)
        │
        ▼
   aiogram bot          ← сохраняет историю в SQLite
        │
        ▼
  Celery task           ← вызывает OpenRouter AI
        │
        ▼
  Telegram API          ← отвечает с typing simulation
```

**Рандомизация ответов** (чтобы не было похоже на бота):
- 30% — разбивает ответ на 2 отдельных сообщения
- 40% — добавляет вопрос в конце
- Задержка 1–3 сек + индикатор «печатает...»
- Максимум 512 символов

---

## Быстрый старт (без Docker / без Redis)

### Требования
- Python 3.10+
- Telegram Bot Token ([BotFather](https://t.me/BotFather))
- OpenRouter API Key ([openrouter.ai](https://openrouter.ai/))

> Я веду канал про автоматизацию и ботов: https://t.me/automation_records

### 1. Клонируй репозиторий

```bash
git clone https://github.com/your-username/assist_bot.git
cd assist_bot
```

### 2. Настрой переменные окружения

```bash
cp .env.example .env
```

Открой `.env` и заполни:

```env
BOT_TOKEN=your_telegram_bot_token
OPENROUTER_API_KEY=your_openrouter_api_key
```

### 3. Запусти локально

1) Установи зависимости

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -U pip
pip install -r requirements.txt
```

2) Запусти бота

```bash
source .venv/bin/activate
python -m bot.main
```

База данных SQLite сохранится в `./data/bot.db`.

---

## Настройка Telegram Business

1. Открой **Настройки → Telegram Business → Чат-боты**
2. Найди своего бота и добавь его
3. Выбери чаты, в которых он будет отвечать
4. Напиши боту `/start` в обычном чате
5. Нажми **«Задать промпт»** и опиши свой стиль общения

> После этого бот начнёт автоматически отвечать в выбранных чатах.

---

## Промпт — как написать хороший

Промпт — это описание того, как ты общаешься. Чем точнее, тем лучше.

**Пример хорошего промпта:**
```
Я общаюсь неформально, без смайликов, коротко и по делу. 
Работаю разработчиком, поэтому в IT темах отвечаю подробнее. 
Не люблю воду и длинные сообщения. Иногда шучу.
```

**Плохой промпт:**
```
Отвечай как я
```

---

## Команды бота

| Команда / кнопка | Действие |
|---|---|
| `/start` | Главное меню |
| ✏️ Задать промпт | Установить/обновить свой промпт |
| 📋 Мой текущий промпт | Посмотреть активный промпт |

---

## Структура проекта

```
assist_bot/
├── bot/
│   ├── handlers/
│   │   ├── start.py       # /start, просмотр промпта
│   │   ├── prompt.py      # FSM: сохранение промпта
│   │   └── business.py    # обработка Business сообщений
│   ├── keyboards.py
│   ├── middleware.py      # DB сессия в хендлеры
│   ├── states.py
│   └── main.py
├── worker/
│   ├── celery_app.py
│   └── tasks.py           # AI запрос + отправка ответа
├── db/
│   ├── models.py          # User, BusinessConnection, Message
│   └── database.py
├── config.py
├── docker-compose.yml
└── .env.example
```

---

## Обновление бота

```bash
docker-compose down && docker-compose up --build
```

База данных хранится в `./data/bot.db` на хосте и **не удаляется** при пересборке.

---

## 🎓 Хочешь научиться делать таких ботов?

Этот проект — часть курса по разработке Telegram-ботов на Python.

Если хочешь разбираться в aiogram, базах данных, очередях задач и деплое — заходи:

### 👉 [sudoteach.com/course/aiogram](https://sudoteach.com/course/aiogram)

На курсе ты научишься:
- Строить ботов любой сложности на aiogram 3
- Работать с базами данных через SQLAlchemy
- Интегрировать AI и внешние API
- Деплоить через Docker

---

## Лицензия

MIT
