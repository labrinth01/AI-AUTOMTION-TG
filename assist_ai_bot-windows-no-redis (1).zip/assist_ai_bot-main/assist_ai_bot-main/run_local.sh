#!/usr/bin/env bash
set -euo pipefail

# Local (no-Docker) runner.
# Requires: Python 3.10+, Redis.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

if [ ! -f .env ]; then
  echo "[!] .env not found. Copy from .env.example first." >&2
  exit 1
fi

python -m venv .venv
source .venv/bin/activate

pip install -U pip
pip install -r requirements.txt

# Start worker and bot in foreground (two terminals recommended).
# Terminal 1:
#   source .venv/bin/activate
#   celery -A worker.celery_app worker --loglevel=info --concurrency=4
# Terminal 2:
#   source .venv/bin/activate
#   python -m bot.main

echo "OK. Now start Redis, then run worker and bot (see comments)."
