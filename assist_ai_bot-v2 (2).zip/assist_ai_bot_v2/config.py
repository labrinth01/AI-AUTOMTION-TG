from typing import List

from pydantic_settings import BaseSettings


DEFAULT_MODELS = (
    # Primary: Claude Haiku 3.5 (paid) via OpenRouter
    "anthropic/claude-3.5-haiku",
    # Fallbacks (paid, cheap & fast)
    "openai/gpt-4o-mini",
    "google/gemini-2.0-flash-001",
)


class Settings(BaseSettings):
    BOT_TOKEN: str
    OPENROUTER_API_KEY: str
    DATABASE_URL: str = "sqlite+aiosqlite:///./data/bot.db"

    # Comma separated Telegram user ids that are root admins.
    ADMIN_IDS: str = ""

    # Optional override for models (comma separated OpenRouter ids).
    MODELS: str = ""

    model_config = {"env_file": ".env", "extra": "ignore"}

    @property
    def admin_ids(self) -> List[int]:
        out: List[int] = []
        for chunk in self.ADMIN_IDS.split(","):
            chunk = chunk.strip()
            if not chunk:
                continue
            try:
                out.append(int(chunk))
            except ValueError:
                continue
        return out

    @property
    def models(self) -> List[str]:
        if self.MODELS.strip():
            return [m.strip() for m in self.MODELS.split(",") if m.strip()]
        return list(DEFAULT_MODELS)


settings = Settings()
