from aiogram.fsm.state import State, StatesGroup


class PromptForm(StatesGroup):
    waiting_for_prompt = State()


class AdminAddUser(StatesGroup):
    waiting_for_id = State()
    waiting_for_note = State()


class AdminRemoveUser(StatesGroup):
    waiting_for_id = State()
