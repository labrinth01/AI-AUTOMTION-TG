import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.types import Update

from bot.handlers import admin, business, prompt, start
from bot.middleware import DatabaseMiddleware
from config import settings
from db.database import init_db

log = logging.getLogger("assist-bot")

ALLOWED_UPDATES = [
    "message",
    "callback_query",
    "business_connection",
    "business_message",
    "edited_business_message",
    "deleted_business_messages",
]


async def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    await init_db()

    bot = Bot(
        token=settings.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode="HTML"),
    )
    dp = Dispatcher()

    dp.update.middleware(DatabaseMiddleware())

    # Отладка: логируем тип каждого входящего обновления
    @dp.update.outer_middleware()
    async def log_updates(handler, event: Update, data):
        kinds = []
        if event.message:
            kinds.append("message")
        if event.business_connection:
            kinds.append(f"business_connection({event.business_connection.id})")
        if event.business_message:
            kinds.append("business_message")
        if event.edited_business_message:
            kinds.append("edited_business_message")
        if event.callback_query:
            kinds.append("callback_query")
        log.info("⬇️ update id=%s kinds=%s", event.update_id, kinds or ["?"])
        return await handler(event, data)

    dp.include_router(start.router)
    dp.include_router(prompt.router)
    dp.include_router(admin.router)
    dp.include_router(business.router)

    me = await bot.get_me()
    log.info(
        "✅ Bot @%s (id=%s) запущен. can_connect_to_business=%s",
        me.username,
        me.id,
        getattr(me, "can_connect_to_business", None),
    )
    if not getattr(me, "can_connect_to_business", False):
        log.warning(
            "⚠️  Бот НЕ имеет Business Mode! Включи в @BotFather: "
            "/mybots → выбрать бота → Bot Settings → Business Mode → Turn on. "
            "Без этого Telegram НЕ будет присылать business_message."
        )

    await dp.start_polling(bot, allowed_updates=ALLOWED_UPDATES)


if __name__ == "__main__":
    asyncio.run(main())
