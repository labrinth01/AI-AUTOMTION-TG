from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def main_menu(is_admin: bool, bot_enabled: bool) -> InlineKeyboardMarkup:
    toggle_label = "⏸ Пауза бота" if bot_enabled else "▶️ Включить бота"
    rows = [
        [InlineKeyboardButton(text="✏️ Задать промпт", callback_data="set_prompt")],
        [InlineKeyboardButton(text="📋 Мой промпт", callback_data="show_prompt")],
        [InlineKeyboardButton(text=toggle_label, callback_data="toggle_bot")],
        [InlineKeyboardButton(text="ℹ️ Как это работает", callback_data="help")],
    ]
    if is_admin:
        rows.append([InlineKeyboardButton(text="🛠 Админ-панель", callback_data="admin_panel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="❌ Отмена", callback_data="cancel")],
        ]
    )


def admin_panel_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="👥 Список пользователей", callback_data="admin_list")],
            [InlineKeyboardButton(text="➕ Добавить пользователя", callback_data="admin_add")],
            [InlineKeyboardButton(text="➖ Удалить пользователя", callback_data="admin_remove")],
            [InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats")],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="back_main")],
        ]
    )


def back_admin_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ Назад в админку", callback_data="admin_panel")],
        ]
    )


def user_actions_kb(tg_id: int, is_admin: bool, is_active: bool) -> InlineKeyboardMarkup:
    rows = []
    if is_active:
        rows.append([InlineKeyboardButton(text="🚫 Деактивировать", callback_data=f"u_disable:{tg_id}")])
    else:
        rows.append([InlineKeyboardButton(text="✅ Активировать", callback_data=f"u_enable:{tg_id}")])
    if is_admin:
        rows.append([InlineKeyboardButton(text="⬇ Снять админку", callback_data=f"u_unadmin:{tg_id}")])
    else:
        rows.append([InlineKeyboardButton(text="⬆ Сделать админом", callback_data=f"u_admin:{tg_id}")])
    rows.append([InlineKeyboardButton(text="🗑 Удалить", callback_data=f"u_delete:{tg_id}")])
    rows.append([InlineKeyboardButton(text="⬅️ К списку", callback_data="admin_list")])
    return InlineKeyboardMarkup(inline_keyboard=rows)
