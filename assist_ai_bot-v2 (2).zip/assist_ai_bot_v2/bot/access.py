from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings
from db.models import AllowedUser


async def get_user(session: AsyncSession, tg_id: int) -> Optional[AllowedUser]:
    return await session.scalar(select(AllowedUser).where(AllowedUser.tg_id == tg_id))


def _is_root_admin(tg_id: int) -> bool:
    return tg_id in settings.admin_ids


async def is_allowed(session: AsyncSession, tg_id: int) -> bool:
    if _is_root_admin(tg_id):
        return True
    user = await get_user(session, tg_id)
    return bool(user and user.is_active)


async def is_admin(session: AsyncSession, tg_id: int) -> bool:
    if _is_root_admin(tg_id):
        return True
    user = await get_user(session, tg_id)
    return bool(user and user.is_active and user.is_admin)


async def ensure_user_record(
    session: AsyncSession, tg_id: int, username: Optional[str] = None
) -> AllowedUser:
    user = await get_user(session, tg_id)
    if user is None and _is_root_admin(tg_id):
        user = AllowedUser(
            tg_id=tg_id,
            username=username,
            is_admin=True,
            is_active=True,
            note="root admin",
        )
        session.add(user)
        await session.commit()
    elif user and username and user.username != username:
        user.username = username
        await session.commit()
    return user  # type: ignore[return-value]
