from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from bot.access import get_user, is_admin, is_allowed
from bot.keyboards import cancel_keyboard, main_menu
from bot.states import PromptForm
from bot.texts import (
    CANCELED,
    NOT_ALLOWED,
    PROMPT_ASK,
    PROMPT_SAVED,
    PROMPT_TOO_SHORT,
)

router = Router()


@router.callback_query(F.data == "set_prompt")
async def ask_prompt(
    callback: CallbackQuery, state: FSMContext, session: AsyncSession
) -> None:
    if not await is_allowed(session, callback.from_user.id):
        await callback.answer("Доступ ограничен", show_alert=True)
        return
    await callback.message.answer(PROMPT_ASK, reply_markup=cancel_keyboard())
    await state.set_state(PromptForm.waiting_for_prompt)
    await callback.answer()


@router.callback_query(F.data == "show_prompt")
async def show_prompt(callback: CallbackQuery, session: AsyncSession) -> None:
    user = await get_user(session, callback.from_user.id)
    if not user or not user.prompt:
        text = "📋 <b>Текущий промпт</b>\n\n<i>Пусто</i>"
    else:
        text = (
            "📋 <b>Текущий промпт</b>\n\n"
            f"<blockquote>{user.prompt}</blockquote>"
        )
    admin = await is_admin(session, callback.from_user.id)
    enabled = bool(user.bot_enabled) if user else True
    await callback.message.edit_text(
        text, reply_markup=main_menu(is_admin=admin, bot_enabled=enabled)
    )
    await callback.answer()


@router.callback_query(F.data == "cancel")
async def cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.answer(CANCELED)
    await callback.answer()


@router.message(PromptForm.waiting_for_prompt)
async def save_prompt(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    if not await is_allowed(session, message.from_user.id):
        await message.answer(NOT_ALLOWED.format(tg_id=message.from_user.id))
        await state.clear()
        return

    text = (message.text or "").strip()
    if len(text) < 10:
        await message.answer(PROMPT_TOO_SHORT)
        return

    user = await get_user(session, message.from_user.id)
    if user is None:
        await message.answer(NOT_ALLOWED.format(tg_id=message.from_user.id))
        await state.clear()
        return

    user.prompt = text
    await session.commit()
    await state.clear()

    admin = await is_admin(session, message.from_user.id)
    await message.answer(
        PROMPT_SAVED,
        reply_markup=main_menu(is_admin=admin, bot_enabled=user.bot_enabled),
    )
