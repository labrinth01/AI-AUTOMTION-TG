from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from bot.access import ensure_user_record, get_user, is_admin, is_allowed
from bot.keyboards import main_menu
from bot.texts import HELP, NOT_ALLOWED, WELCOME_ADMIN, WELCOME_USER

router = Router()


async def _show_main(message: Message, session: AsyncSession) -> None:
    tg_id = message.from_user.id
    if not await is_allowed(session, tg_id):
        await message.answer(NOT_ALLOWED.format(tg_id=tg_id))
        return

    user = await ensure_user_record(session, tg_id, message.from_user.username)
    admin = await is_admin(session, tg_id)
    bot_enabled = bool(user.bot_enabled) if user else True
    name = message.from_user.first_name or "друг"
    text = WELCOME_ADMIN if admin else WELCOME_USER
    await message.answer(
        text.format(name=name),
        reply_markup=main_menu(is_admin=admin, bot_enabled=bot_enabled),
    )


@router.message(CommandStart())
async def start_cmd(message: Message, session: AsyncSession) -> None:
    await _show_main(message, session)


@router.callback_query(F.data == "back_main")
async def back_main(callback: CallbackQuery, session: AsyncSession) -> None:
    tg_id = callback.from_user.id
    user = await get_user(session, tg_id)
    admin = await is_admin(session, tg_id)
    bot_enabled = bool(user.bot_enabled) if user else True
    name = callback.from_user.first_name or "друг"
    text = WELCOME_ADMIN if admin else WELCOME_USER
    await callback.message.edit_text(
        text.format(name=name),
        reply_markup=main_menu(is_admin=admin, bot_enabled=bot_enabled),
    )
    await callback.answer()


@router.callback_query(F.data == "help")
async def show_help(callback: CallbackQuery, session: AsyncSession) -> None:
    admin = await is_admin(session, callback.from_user.id)
    user = await get_user(session, callback.from_user.id)
    bot_enabled = bool(user.bot_enabled) if user else True
    await callback.message.edit_text(
        HELP, reply_markup=main_menu(is_admin=admin, bot_enabled=bot_enabled)
    )
    await callback.answer()


@router.callback_query(F.data == "toggle_bot")
async def toggle_bot(callback: CallbackQuery, session: AsyncSession) -> None:
    user = await get_user(session, callback.from_user.id)
    if not user:
        await callback.answer("Нет доступа", show_alert=True)
        return
    user.bot_enabled = not user.bot_enabled
    await session.commit()
    admin = await is_admin(session, callback.from_user.id)
    name = callback.from_user.first_name or "друг"
    text = WELCOME_ADMIN if admin else WELCOME_USER
    await callback.message.edit_text(
        text.format(name=name),
        reply_markup=main_menu(is_admin=admin, bot_enabled=user.bot_enabled),
    )
    await callback.answer(
        "✅ Бот включён" if user.bot_enabled else "⏸ Бот на паузе"
    )
