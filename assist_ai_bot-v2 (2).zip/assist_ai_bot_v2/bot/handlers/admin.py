from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from bot.access import get_user, is_admin
from bot.keyboards import (
    admin_panel_kb,
    back_admin_kb,
    cancel_keyboard,
    user_actions_kb,
)
from bot.states import AdminAddUser, AdminRemoveUser
from bot.texts import (
    ADD_USER_ASK_ID,
    ADD_USER_ASK_NOTE,
    ADMIN_PANEL,
    BAD_ID,
    CANT_TOUCH_SELF,
    REMOVE_USER_ASK_ID,
    USER_NOT_FOUND,
)
from db.models import AllowedUser, Message as MessageModel

router = Router()


async def _ensure_admin(callback: CallbackQuery, session: AsyncSession) -> bool:
    if not await is_admin(session, callback.from_user.id):
        await callback.answer("⛔️ Только для админов", show_alert=True)
        return False
    return True


@router.callback_query(F.data == "admin_panel")
async def open_panel(callback: CallbackQuery, session: AsyncSession) -> None:
    if not await _ensure_admin(callback, session):
        return
    await callback.message.edit_text(ADMIN_PANEL, reply_markup=admin_panel_kb())
    await callback.answer()


@router.callback_query(F.data == "admin_list")
async def admin_list(callback: CallbackQuery, session: AsyncSession) -> None:
    if not await _ensure_admin(callback, session):
        return
    rows = (
        await session.execute(select(AllowedUser).order_by(AllowedUser.created_at))
    ).scalars().all()

    if not rows:
        text = "👥 <b>Пользователи</b>\n\n<i>Пусто</i>"
        kb = back_admin_kb()
    else:
        lines = ["👥 <b>Пользователи</b>\n"]
        kb_rows = []
        for u in rows:
            badge = "🔑" if u.is_admin else ("✅" if u.is_active else "🚫")
            uname = f"@{u.username}" if u.username else "—"
            note = f" · {u.note}" if u.note else ""
            lines.append(
                f"{badge} <code>{u.tg_id}</code> {uname}{note}"
            )
            kb_rows.append(
                [
                    {
                        "text": f"{badge} {u.tg_id}",
                        "callback_data": f"u_view:{u.tg_id}",
                    }
                ]
            )

        from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text=r[0]["text"], callback_data=r[0]["callback_data"])
                ]
                for r in kb_rows
            ]
            + [
                [
                    InlineKeyboardButton(
                        text="⬅️ Назад в админку", callback_data="admin_panel"
                    )
                ]
            ]
        )
        text = "\n".join(lines)

    await callback.message.edit_text(text, reply_markup=kb)
    await callback.answer()


@router.callback_query(F.data.startswith("u_view:"))
async def user_view(callback: CallbackQuery, session: AsyncSession) -> None:
    if not await _ensure_admin(callback, session):
        return
    tg_id = int(callback.data.split(":", 1)[1])
    u = await get_user(session, tg_id)
    if not u:
        await callback.answer(USER_NOT_FOUND, show_alert=True)
        return
    badge = "🔑 Админ" if u.is_admin else ("✅ Активен" if u.is_active else "🚫 Деактивирован")
    text = (
        f"👤 <b>Пользователь</b>\n\n"
        f"ID: <code>{u.tg_id}</code>\n"
        f"@: {('@' + u.username) if u.username else '—'}\n"
        f"Статус: {badge}\n"
        f"Заметка: {u.note or '—'}\n"
        f"Бот: {'▶️ вкл' if u.bot_enabled else '⏸ пауза'}"
    )
    await callback.message.edit_text(
        text,
        reply_markup=user_actions_kb(
            tg_id=u.tg_id, is_admin=u.is_admin, is_active=u.is_active
        ),
    )
    await callback.answer()


async def _toggle(
    callback: CallbackQuery, session: AsyncSession, attr: str, value: bool
) -> None:
    if not await _ensure_admin(callback, session):
        return
    tg_id = int(callback.data.split(":", 1)[1])
    if tg_id == callback.from_user.id and attr == "is_admin" and value is False:
        await callback.answer(CANT_TOUCH_SELF, show_alert=True)
        return
    u = await get_user(session, tg_id)
    if not u:
        await callback.answer(USER_NOT_FOUND, show_alert=True)
        return
    setattr(u, attr, value)
    await session.commit()
    await user_view(callback, session)


@router.callback_query(F.data.startswith("u_enable:"))
async def u_enable(callback: CallbackQuery, session: AsyncSession) -> None:
    await _toggle(callback, session, "is_active", True)


@router.callback_query(F.data.startswith("u_disable:"))
async def u_disable(callback: CallbackQuery, session: AsyncSession) -> None:
    await _toggle(callback, session, "is_active", False)


@router.callback_query(F.data.startswith("u_admin:"))
async def u_admin(callback: CallbackQuery, session: AsyncSession) -> None:
    await _toggle(callback, session, "is_admin", True)


@router.callback_query(F.data.startswith("u_unadmin:"))
async def u_unadmin(callback: CallbackQuery, session: AsyncSession) -> None:
    await _toggle(callback, session, "is_admin", False)


@router.callback_query(F.data.startswith("u_delete:"))
async def u_delete(callback: CallbackQuery, session: AsyncSession) -> None:
    if not await _ensure_admin(callback, session):
        return
    tg_id = int(callback.data.split(":", 1)[1])
    if tg_id == callback.from_user.id:
        await callback.answer(CANT_TOUCH_SELF, show_alert=True)
        return
    u = await get_user(session, tg_id)
    if not u:
        await callback.answer(USER_NOT_FOUND, show_alert=True)
        return
    await session.delete(u)
    await session.commit()
    await callback.answer("Удалёно")
    callback.data = "admin_list"
    await admin_list(callback, session)


# ---- Add user flow ----
@router.callback_query(F.data == "admin_add")
async def admin_add(
    callback: CallbackQuery, state: FSMContext, session: AsyncSession
) -> None:
    if not await _ensure_admin(callback, session):
        return
    await callback.message.answer(ADD_USER_ASK_ID, reply_markup=cancel_keyboard())
    await state.set_state(AdminAddUser.waiting_for_id)
    await callback.answer()


@router.message(AdminAddUser.waiting_for_id)
async def admin_add_id(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    if not await is_admin(session, message.from_user.id):
        await state.clear()
        return
    text = (message.text or "").strip()
    try:
        tg_id = int(text)
    except ValueError:
        await message.answer(BAD_ID)
        return

    existing = await get_user(session, tg_id)
    if existing:
        existing.is_active = True
        await session.commit()
        await state.clear()
        await message.answer(
            f"✅ Пользователь <code>{tg_id}</code> уже был в базе — включил.",
            reply_markup=admin_panel_kb(),
        )
        return

    await state.update_data(new_user_id=tg_id)
    await state.set_state(AdminAddUser.waiting_for_note)
    await message.answer(ADD_USER_ASK_NOTE, reply_markup=cancel_keyboard())


@router.message(AdminAddUser.waiting_for_note)
async def admin_add_note(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    if not await is_admin(session, message.from_user.id):
        await state.clear()
        return
    data = await state.get_data()
    tg_id = data.get("new_user_id")
    if not tg_id:
        await state.clear()
        return
    note = (message.text or "").strip()
    if note == "-":
        note = None
    session.add(
        AllowedUser(
            tg_id=tg_id,
            is_admin=False,
            is_active=True,
            note=note,
            added_by=message.from_user.id,
        )
    )
    await session.commit()
    await state.clear()
    await message.answer(
        f"✅ Пользователь <code>{tg_id}</code> добавлен.",
        reply_markup=admin_panel_kb(),
    )


# ---- Remove user flow ----
@router.callback_query(F.data == "admin_remove")
async def admin_remove(
    callback: CallbackQuery, state: FSMContext, session: AsyncSession
) -> None:
    if not await _ensure_admin(callback, session):
        return
    await callback.message.answer(REMOVE_USER_ASK_ID, reply_markup=cancel_keyboard())
    await state.set_state(AdminRemoveUser.waiting_for_id)
    await callback.answer()


@router.message(AdminRemoveUser.waiting_for_id)
async def admin_remove_id(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    if not await is_admin(session, message.from_user.id):
        await state.clear()
        return
    text = (message.text or "").strip()
    try:
        tg_id = int(text)
    except ValueError:
        await message.answer(BAD_ID)
        return
    if tg_id == message.from_user.id:
        await message.answer(CANT_TOUCH_SELF)
        return
    u = await get_user(session, tg_id)
    if not u:
        await message.answer(USER_NOT_FOUND)
        return
    await session.delete(u)
    await session.commit()
    await state.clear()
    await message.answer(
        f"🗑 Пользователь <code>{tg_id}</code> удалён.",
        reply_markup=admin_panel_kb(),
    )


# ---- Stats ----
@router.callback_query(F.data == "admin_stats")
async def admin_stats(callback: CallbackQuery, session: AsyncSession) -> None:
    if not await _ensure_admin(callback, session):
        return
    users_total = await session.scalar(select(func.count(AllowedUser.id)))
    users_admins = await session.scalar(
        select(func.count(AllowedUser.id)).where(AllowedUser.is_admin == True)
    )
    users_active = await session.scalar(
        select(func.count(AllowedUser.id)).where(AllowedUser.is_active == True)
    )
    messages_total = await session.scalar(select(func.count(MessageModel.id)))
    text = (
        "📊 <b>Статистика</b>\n\n"
        f"👥 Пользователей всего: <b>{users_total or 0}</b>\n"
        f"✅ Активных: <b>{users_active or 0}</b>\n"
        f"🔑 Админов: <b>{users_admins or 0}</b>\n"
        f"💬 Сообщений в истории: <b>{messages_total or 0}</b>"
    )
    await callback.message.edit_text(text, reply_markup=back_admin_kb())
    await callback.answer()
