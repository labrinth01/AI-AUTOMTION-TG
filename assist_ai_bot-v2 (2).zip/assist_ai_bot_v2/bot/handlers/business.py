import logging

from aiogram import Router
from aiogram.types import BusinessConnection, Message
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from bot.access import get_user
from bot.ai import process_message_in_background, spawn_ai_reply_task
from db.models import BusinessConnection as BCModel
from db.models import Message as MessageModel

log = logging.getLogger(__name__)
router = Router()


@router.business_connection()
async def on_business_connection(
    event: BusinessConnection, session: AsyncSession
) -> None:
    log.info(
        "🔗 business_connection id=%s user=%s enabled=%s can_reply=%s",
        event.id, event.user.id, event.is_enabled, event.can_reply,
    )
    existing = await session.get(BCModel, event.id)
    if existing:
        existing.is_enabled = event.is_enabled
        existing.can_reply = event.can_reply
        existing.tg_user_id = event.user.id
    else:
        session.add(
            BCModel(
                id=event.id,
                tg_user_id=event.user.id,
                is_enabled=event.is_enabled,
                can_reply=event.can_reply,
            )
        )
    await session.commit()


@router.business_message()
async def handle_business_message(
    message: Message, session: AsyncSession
) -> None:
    log.info(
        "📬 business_message bc=%s from=%s chat=%s text=%r",
        message.business_connection_id,
        message.from_user.id if message.from_user else None,
        message.chat.id,
        (message.text or "")[:80],
    )
    if not message.business_connection_id or not message.text:
        log.info("   → пропуск: нет bc_id или текста")
        return

    bc = await session.get(BCModel, message.business_connection_id)
    if not bc:
        log.warning("   → пропуск: business_connection не найден в БД")
        return
    if not bc.is_enabled or not bc.can_reply:
        log.info("   → пропуск: bc.enabled=%s can_reply=%s", bc.is_enabled, bc.can_reply)
        return

    owner_id = bc.tg_user_id

    owner = await get_user(session, owner_id)
    if not owner:
        log.info("   → пропуск: владелец %s не в whitelist", owner_id)
        return
    if not owner.is_active:
        log.info("   → пропуск: владелец %s неактивен", owner_id)
        return
    if not owner.bot_enabled:
        log.info("   → пропуск: владелец %s поставил бота на паузу", owner_id)
        return

    if message.from_user and message.from_user.id == owner_id:
        log.info("   → пропуск: сообщение от самого владельца")
        return

    log.info("   → ✅ запускаю AI-ответ для владельца %s", owner_id)

    user_prompt = owner.prompt if owner.prompt else None

    rows = await session.execute(
        select(MessageModel)
        .where(
            MessageModel.tg_user_id == owner_id,
            MessageModel.chat_id == message.chat.id,
        )
        .order_by(MessageModel.created_at.desc())
        .limit(10)
    )
    history = [
        {"role": m.role, "content": m.content}
        for m in reversed(rows.scalars().all())
    ]

    session.add(
        MessageModel(
            tg_user_id=owner_id,
            chat_id=message.chat.id,
            role="user",
            content=message.text,
        )
    )
    await session.commit()

    spawn_ai_reply_task(
        process_message_in_background(
            owner_id,
            message.chat.id,
            message.business_connection_id,
            message.text,
            user_prompt,
            history,
        )
    )
