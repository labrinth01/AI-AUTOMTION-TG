# 🤖 Telegram Business AutoReply Bot v2

AI-автоответчик для **Telegram Business** с админ-панелью и контролем доступа.  
Проект от [@automation_records](https://t.me/automation_records).

## Что умеет

- Отвечает в выбранных чатах Telegram Business в **твоём стиле** (промпт)
- **Админ-панель**: добавить/удалить пользователя, выдать/снять админку, вкл/выкл, статистика
- **Доступ только для разрешённых пользователей** (whitelist)
- Красивые HTML-сообщения, стабильный UX
- **Платные модели** через OpenRouter (по умолчанию: **Claude Haiku 3.5**)
- Без Docker, без Redis, без Celery — **один процесс**

## Стек

- aiogram 3
- SQLAlchemy + aiosqlite
- httpx
- OpenRouter (Claude Haiku 3.5 + fallback на GPT-4o-mini, Gemini Flash)

## Настройка .env

```env
BOT_TOKEN=...                    # токен от @BotFather
OPENROUTER_API_KEY=...           # ключ openrouter.ai
ADMIN_IDS=123456789,987654321    # Telegram ID роот-админов (через запятую)
# MODELS=anthropic/claude-3.5-haiku,openai/gpt-4o-mini   # опционально
DATABASE_URL=sqlite+aiosqlite:///./data/bot.db
```

Где взять `ADMIN_IDS`: напиши [@userinfobot](https://t.me/userinfobot) — он пришлёт твой ID.

## Запуск локально

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -r requirements.txt

cp .env.example .env
nano .env

python -m bot.main
```

### Windows (PowerShell)

```powershell
py -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
.\.venv\Scripts\Activate.ps1
pip install -U pip
pip install -r requirements.txt

copy .env.example .env
notepad .env

py -m bot.main
```

## Запуск на хостинге (VPS, Ubuntu)

### 1) Подготовь сервер

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip git
```

### 2) Залей проект

```bash
cd /opt
sudo git clone <YOUR_REPO_URL> assist_ai_bot
sudo chown -R $USER:$USER /opt/assist_ai_bot
cd /opt/assist_ai_bot

python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -r requirements.txt

cp .env.example .env
nano .env  # впиши BOT_TOKEN, OPENROUTER_API_KEY, ADMIN_IDS
```

### 3) systemd сервис (автозапуск)

Создай `/etc/systemd/system/assist-bot.service`:

```ini
[Unit]
Description=Assist AI Telegram Business bot (v2)
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/opt/assist_ai_bot
EnvironmentFile=/opt/assist_ai_bot/.env
ExecStart=/opt/assist_ai_bot/.venv/bin/python -m bot.main
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
```

Активация:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now assist-bot.service
sudo journalctl -u assist-bot -f
```

### 4) Обновление

```bash
cd /opt/assist_ai_bot
git pull
source .venv/bin/activate
pip install -r requirements.txt
sudo systemctl restart assist-bot
```

## Первый запуск

1) Стартуй бота.
2) Напиши ему `/start` — ты увидишь админ-меню (ты из `ADMIN_IDS`).
3) В **Админ-панель** → **Добавить пользователя** впиши Telegram ID и заметку.
4) Пользователь пишет `/start`, задаёт свой промпт и подключает бота в *Telegram Business → Чат-боты*.

## Модели

По умолчанию в приоритете (платные, без :free):

1. `anthropic/claude-3.5-haiku`
2. `openai/gpt-4o-mini`
3. `google/gemini-2.0-flash-001`

Переопределить можно через `MODELS=` в `.env`.

## Лицензия

См. `LICENSE`.  
Источник/авторство: **https://t.me/automation_records**
