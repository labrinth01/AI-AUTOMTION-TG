import os

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from config import settings
from db.models import AllowedUser, Base

os.makedirs("data", exist_ok=True)

engine = create_async_engine(settings.DATABASE_URL, echo=False)
async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    # Seed root admins from env
    from sqlalchemy import select

    async with async_session() as session:
        for admin_id in settings.admin_ids:
            existing = await session.scalar(
                select(AllowedUser).where(AllowedUser.tg_id == admin_id)
            )
            if existing is None:
                session.add(
                    AllowedUser(
                        tg_id=admin_id,
                        is_admin=True,
                        is_active=True,
                        note="root admin (env)",
                    )
                )
            else:
                existing.is_admin = True
                existing.is_active = True
        await session.commit()
